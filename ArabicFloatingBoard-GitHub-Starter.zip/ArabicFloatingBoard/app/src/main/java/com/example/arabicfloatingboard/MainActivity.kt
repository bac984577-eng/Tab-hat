package com.example.arabicfloatingboard

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "السبورة العربية العائمة"
            textSize = 24f
            text = "السبورة العربية العائمة\nنسخة تجريبية مفتوحة المصدر"
        })
        root.addView(TextView(this).apply {
            text = "\n1) اسمح للتطبيق بالظهور فوق التطبيقات.\n" +
                "2) اضغط تشغيل السبورة.\n\n" +
                "هذه النسخة تسجل اللمسات/الكتابة وتعرض لوحة عائمة. " +
                "تحويل الخط اليدوي العربي إلى نص واضح يحتاج إلى محرك تعرّف على الكتابة العربية؛ " +
                "لم نضع محركًا وهميًا يدّعي أنه يعمل."
            textSize = 16f
        })
        root.addView(Button(this).apply {
            text = "منح إذن الظهور فوق التطبيقات"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "الإذن ممنوح", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "تشغيل السبورة العائمة"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "امنح الإذن أولًا", Toast.LENGTH_LONG).show()
                } else {
                    startService(Intent(this@MainActivity, FloatingBoardService::class.java))
                    Toast.makeText(this@MainActivity, "تم تشغيل السبورة", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        })
        setContentView(root)
    }
}
