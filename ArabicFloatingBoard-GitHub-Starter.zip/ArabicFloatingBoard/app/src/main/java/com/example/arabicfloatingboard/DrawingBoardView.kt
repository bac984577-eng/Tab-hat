package com.example.arabicfloatingboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View

class DrawingBoardView(context: Context) : View(context) {
    private data class Stroke(val path: Path, val color: Int, val width: Float)
    private val strokes = mutableListOf<Stroke>()
    private var activePath: Path? = null
    private var inkColor = Color.rgb(35, 82, 180)
    private var inkWidth = 7f * resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    init { setBackgroundColor(Color.WHITE) }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        // Faint guide lines make handwriting easier to align.
        val guide = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(239, 242, 248)
            strokeWidth = resources.displayMetrics.density
        }
        var y = 42f * resources.displayMetrics.density
        while (y < height) {
            canvas.drawLine(0f, y, width.toFloat(), y, guide)
            y += 42f * resources.displayMetrics.density
        }
        for (stroke in strokes) {
            paint.color = stroke.color
            paint.strokeWidth = stroke.width
            canvas.drawPath(stroke.path, paint)
        }
        activePath?.let {
            paint.color = inkColor
            paint.strokeWidth = inkWidth
            canvas.drawPath(it, paint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                activePath = Path().apply { moveTo(x, y) }
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                activePath?.lineTo(x, y)
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                activePath?.let { strokes.add(Stroke(it, inkColor, inkWidth)) }
                activePath = null
                invalidate()
                performClick()
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    fun clearDrawing() {
        strokes.clear()
        activePath = null
        invalidate()
    }
}
