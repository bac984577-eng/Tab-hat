package com.example.arabicfloatingboard

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class FloatingBoardService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var board: DrawingBoardView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel == null) showBoard()
        return START_NOT_STICKY
    }

    private fun showBoard() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val density = resources.displayMetrics.density
        fun dp(n: Int) = (n * density).toInt()

        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), Color.rgb(220, 225, 235))
            }
            elevation = dp(12).toFloat()
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "✍ السبورة العربية"
            textSize = 16f
            setTextColor(Color.rgb(35, 45, 65))
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(42), 1f))
        val close = Button(this).apply {
            text = "×"
            setOnClickListener { stopSelf() }
        }
        header.addView(close, LinearLayout.LayoutParams(dp(48), dp(42)))
        shell.addView(header)

        board = DrawingBoardView(this)
        shell.addView(board, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(240)
        ))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        controls.addView(Button(this).apply {
            text = "مسح"
            setOnClickListener { board?.clearDrawing() }
        }, LinearLayout.LayoutParams(0, dp(44), 1f))
        controls.addView(Button(this).apply {
            text = "نسخ صورة الكتابة"
            setOnClickListener {
                Toast.makeText(this@FloatingBoardService,
                    "هذه نسخة أولية: يلزم ربط محرك للتعرّف على الكتابة العربية.",
                    Toast.LENGTH_LONG).show()
            }
        }, LinearLayout.LayoutParams(0, dp(44), 1f))
        shell.addView(controls)

        val note = TextView(this).apply {
            text = "مربع النص الناتج سيظهر هنا بعد ربط محرك التعرف العربي."
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(dp(4), dp(6), dp(4), dp(2))
        }
        shell.addView(note)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            dp(330), WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        // Drag the floating window from the header.
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    wm.updateViewLayout(shell, params)
                    true
                }
                else -> false
            }
        }
        panel = shell
        wm.addView(shell, params)
    }

    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }
}
